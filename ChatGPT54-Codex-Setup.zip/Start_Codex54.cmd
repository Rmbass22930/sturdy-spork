@echo off
setlocal EnableExtensions
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start_Codex54.ps1" %*
exit /b %ERRORLEVEL%
