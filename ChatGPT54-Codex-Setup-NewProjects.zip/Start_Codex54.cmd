@echo off
setlocal EnableExtensions
color 0F
powershell.exe -NoLogo -ExecutionPolicy Bypass -File "%~dp0Start_Codex54.ps1" %*
exit /b %ERRORLEVEL%
