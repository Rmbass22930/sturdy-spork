﻿# codex_profile.ps1 (project-local)
# Always use ChatGPT/Codex 5.3 by default; easy to update later.

$script:CODEX_MODEL = "gpt-5.3-codex"   # <-- change this later when new version comes out

function cx {
    param(
        [Parameter(ValueFromRemainingArguments=$true)]
        [string[]]$Args
    )
    # --skip-git-repo-check avoids the "trusted directory" / git requirement
    codex -m $script:CODEX_MODEL --skip-git-repo-check @Args
}

Set-Alias codex53 cx

Write-Host "Loaded project Codex profile. Model = $script:CODEX_MODEL" -ForegroundColor Green
